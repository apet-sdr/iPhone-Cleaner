# SpaceCleaner: build on GitHub, install without Xcode

## 1. Build the IPA in the cloud
1. Create a new **private** repo on GitHub.
2. Upload everything in this folder to it, keeping the structure: `project.yml`, `SpaceCleaner/`, and `.github/workflows/build.yml`. Dot-folders are hidden on some systems, so on github.com use **Add file → Upload files** and drag the whole folder in, or push with git.
3. Open the repo's **Actions** tab. The "Build IPA" workflow runs on every push to `main`. You can also start it with **Run workflow**.
4. When it shows a green check (about 5 to 10 minutes), open the run and download the **SpaceCleaner-ipa** artifact at the bottom. It's a zip, so unzip it to get `SpaceCleaner.ipa`.

If the run fails, open the red step and copy the error text. A small Swift error is possible since the code hasn't been compiled yet, and it's usually a one-line fix.

## 2. Install on your iPhone (Windows or Mac)
**Sideloadly** (simplest):
1. Install Sideloadly from sideloadly.io, plus iTunes and iCloud on Windows (the **website** versions, not the Microsoft Store ones).
2. Plug in your iPhone and tap Trust.
3. Drag `SpaceCleaner.ipa` into Sideloadly, enter your Apple ID, and click Start.
4. On the phone: Settings → Privacy & Security → turn on **Developer Mode** (it restarts the phone).
5. Settings → General → VPN & Device Management → tap your Apple ID → **Trust**.

**AltStore** does the same but auto-refreshes the 7-day expiry while your PC runs AltServer on the same Wi-Fi.

Free Apple ID limits: the app expires every 7 days (just reinstall or refresh) and you can have 3 sideloaded apps at once.

## 3. Using it
Open SpaceCleaner, allow Photos access, scan, Select All, review, Delete.
Photos go to Recently Deleted for 30 days. Files deleted from the Files tab are permanent.
