# SpaceCleaner (SwiftUI, iOS 17+)

Storage overview and tips, a photo/video cleaner, and a folder cleaner. All with Select All and a confirm step before anything is deleted.

## Setup (needs a Mac with Xcode)
1. Xcode → File → New → Project → iOS → App. Name it SpaceCleaner, Interface: SwiftUI, Language: Swift.
2. Delete the template's `SpaceCleanerApp.swift` and `ContentView.swift`, then drag in all five `.swift` files from this folder (tick "Copy items if needed").
3. Select the project → target → Info tab → add the key
   `Privacy - Photo Library Usage Description` (NSPhotoLibraryUsageDescription)
   with a value like: "Find large videos and screenshots so you can delete them."
4. Signing & Capabilities → pick your personal team (a free Apple ID works).
5. Plug in your iPhone, select it as the run destination, press Run. Turn on Developer Mode on the phone if asked (Settings → Privacy & Security → Developer Mode). With a free account the app expires after 7 days and needs re-running.

## What it does
- **Storage**: used and free space, plus the built-in iOS ways to save space.
- **Photos**: scans for videos over 100 MB and screenshots. Deletes go to Recently Deleted (30 days) and iOS asks you to confirm.
- **Files**: you pick a folder. It finds duplicate files (SHA-256), files over 10 MB, and files untouched for a year. Deletes there are permanent.

## Limits (iOS sandbox)
- Only sees the photos and folders you allow. No access to other apps' data, caches, or System Data.
- Can't free RAM or GPU memory. iOS controls that.
- `fileSize` for photo assets uses an undocumented key that works today but could change.

## Ideas to add later
Duplicate and similar photo detection (Vision feature prints), blurry photo detection, Live Photo to still conversion, a safety "protect these folders" list.
